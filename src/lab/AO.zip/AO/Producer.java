package lab.AO;

import java.util.Random;

public class Producer implements Runnable{
    private final int maxPortion;
    private static final Random random = new Random(1);
    private final Proxy proxy;

    public Producer(int maxBufferSize, Proxy proxy){
        maxPortion = maxBufferSize/2;
        this.proxy = proxy;
    }

    @Override
    public void run() {
        while(true){
            Future future = proxy.produce(getAmountToProduce());
            while (!future.isReady())                            // asynchroniczne oczekiwanie na wykonanie zleconego zadania
                this.doSomeWork();                              // producent w czasie czekania wykonuje inne zadania, sprawdzając po
                                                                // każdym zadaniu czy zadanie na zasobach współdzielonych zostało wykonane
        }
    }

    public void doSomeWork(){
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private int getAmountToProduce(){
        return random.nextInt(maxPortion)+1;
    }
}
