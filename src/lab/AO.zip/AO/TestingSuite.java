package lab.AO;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TestingSuite {
    static final long WORKING_TIME = 10;
    static final int BUFFER_SIZE = 10;
    static final int PRODUCERS_NO = 3;
    static final int CONSUMERS_NO = 3;
    final Proxy proxy;
    final Servant servant;

    private final List<Thread> producersConsumersList;

    public TestingSuite(){
        servant = new Servant(BUFFER_SIZE,WORKING_TIME);
        proxy = new Proxy(servant);
        producersConsumersList = new ArrayList<>();

        for(int i =0;i<CONSUMERS_NO;i++){
            Thread thread = new Thread(new Consumer(BUFFER_SIZE,proxy));
            thread.setName(String.format( "Consumer no:%s", i));
            producersConsumersList.add(thread);
        }

        for(int i =0;i<PRODUCERS_NO;i++){
            Thread thread = new Thread(new Producer(BUFFER_SIZE,proxy));
            thread.setName(String.format( "Producer no:%s", i));
            producersConsumersList.add(thread);
        }

        Collections.shuffle(producersConsumersList);
    }

    public void startSimulation(){
        for(Thread thread : producersConsumersList)
            thread.start();
    }

    public static void main(String[] args) throws InterruptedException {
        TestingSuite testingSuite = new TestingSuite();
        testingSuite.startSimulation();
        while (true)
            Thread.sleep(100);
    }

}
